<?php
use App\Helpers\Helpers;
?>
<?php if(isset($pageConfigs)): ?>
<?php echo Helpers::updatePageConfig($pageConfigs); ?>

<?php endif; ?>
<?php
$configData = Helpers::appClasses();
?>

<?php if(isset($configData["layout"])): ?>
<?php echo $__env->make((( $configData["layout"] === '') ? '' :
(( $configData["layout"] === 'blank') ? '' : 'layouts.contentNavbarLayoutLogin') ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\toters\resources\views/layouts/layoutMasterLogin.blade.php ENDPATH**/ ?>